<?php
/**
 * Created by PhpStorm.
 * User: AUTOCOM-YURI
 * Date: 16/03/2018
 * Time: 18:25
 */

class SistemaException extends Exception
{

}