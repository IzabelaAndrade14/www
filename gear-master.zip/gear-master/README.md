
 ![](/img/logo.png?raw=true)
 
  Projeto a ser desenvolvido para o Curso de Ciências da Computação.  
  Este projeto visa o desenvolvimento de um sistema para gerência de oficinas utilizando as seguintes tecnologias:  
  
  * HTML
  * CSS
  * MySQL
  * PHP
