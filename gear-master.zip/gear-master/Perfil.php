<?php
/**
 * Created by PhpStorm.
 * User: Yuri Lemes
 * Date: 15/03/2018
 * Time: 11:44
 */

abstract class Perfil {
    const ADMIN = "ADMIN";
    const USUARIO = "USUARIO";
}